<?php
$act=$_GET["act"];
$country1=$_GET["country"];
$product1=$_GET["product"];
$id=$_GET["id"];
//5sim.net dan olingan token ↓
$token ="eyJhbGciOiJSUzUxMiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2OTM4NzUzMTgsImlhdCI6MTY2MjMzOTMxOCwicmF5IjoiM2Q5NDczNDJhYzk0YzUzZGM0NGRiYjQzMzlkNWM4ZDQiLCJzdWIiOjExOTYwMzV9.Bd8lyhmjBnrSXyG1o79OyO5WJjKvJ6iYafsGTDQOVA7BqEuYJ4RDGRH78b9YrbCMatQLOQ5QeJ1I2_yySEOmJAMveQCmmb0_qAmtfJYkLUKLaZFz9uIGZ4IfC9ncawmc_aJ47z_Ttt_EEZ2ALfzkazhls1pZoV568iB_AMboHRHqDblZqZgwCjvDNN7x4K5op_Wh7b9m22_2Aq4o6b0Adnp8h5G93WG5fE_nqEE0SsAw3lMSBli6dxYI5e2XOmmkPVBXuHntC_nxZ9YE1MrV2qJk7H0fGlXitysITLsVxpPg5nbPFiXv1Gy1eKt2w23EpNhvLBEL-x0bdo86B_oRgw";
if($act=="number" and $product1!=null and $country1!=null){
/* http://photo-edit.ml/sms.php?act=number&product=telegram&country=russia*/
$ch = curl_init();
$country=$country1;
$operator ="any";
$product =$product1;

curl_setopt($ch, CURLOPT_URL, "https://5sim.net/v1/user/buy/activation/".$country."/".$operator."/".$product);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");


$headers = array();
$headers[] = "Authorization: Bearer ".$token;
$headers[] = "Accept: application/json";
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo "Error:".curl_error($ch);
}
curl_close($ch);
echo $result;
}

if($act=="cancel" and $id!=null){
/* http://photo-edit.ml/sms.php?act=cancel&id=$id*/
$ch = curl_init();
$id1= $id;
curl_setopt($ch, CURLOPT_URL, "https://5sim.net/v1/user/cancel/".$id1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");


$headers = array();
$headers[] = "Authorization: Bearer ".$token;
$headers[] = "Accept: application/json";
curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo "Error:".curl_error($ch);
}
curl_close($ch);
echo $result;
}

if($act=="code" and $id!=null){
/* http://photo-edit.ml/sms.php?act=code&id=$id*/
$ch = curl_init();
$id1=$id;

curl_setopt($ch, CURLOPT_URL, "https://5sim.net/v1/user/check/".$id1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");


$headers = array();
$headers[] = "Authorization: Bearer ".$token;
$headers[] = "Accept: application/json";
curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo "Error:".curl_error($ch);
}
curl_close($ch);
echo $result;
}

if($act=="balance" and $id=="admin"){
	/* http://photo-edit.ml/sms.php?act=balance&id=admin*/
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://5sim.net/v1/user/profile");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
$headers = array();
$headers[] = "Authorization: Bearer ".$token;
$headers[] = "Accept: application/json";
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo "Error:".curl_error($ch);
}
curl_close($ch);
echo $result;
}

if($act=="ban" and $id!=null){
/* http://photo-edit.ml/sms.php?act=ban&id=$id*/
$ch = curl_init();
$id1 = $id;
curl_setopt($ch, CURLOPT_URL, "https://5sim.net/v1/user/ban/".$id);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
$headers = array();
$headers[] = "Authorization: Bearer ".$token;
$headers[] = "Accept: application/json";
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo "Error:".curl_error($ch);
}
curl_close($ch);
echo $result;
}

if($act=="services" and $country1!=null and $product1!=null){
$ch = curl_init();
$country =$country1;
$operator= $product1;

curl_setopt($ch, CURLOPT_URL, "https://5sim.net/v1/guest/products/".$country."/".$operator);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");


$headers = array();
$headers[] = "Accept: application/json";
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo "Error:".curl_error($ch);
}
curl_close($ch);
echo $result;
}

if($act=="prices" and $product1!=null){
$ch = curl_init();
$product1= $product1;

curl_setopt($ch, CURLOPT_URL, "https://5sim.net/v1/guest/prices?product=".$product1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");

$headers = array();
$headers[] = "Accept: application/json";
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo "Error:".curl_error($ch);
}
curl_close($ch);
echo $result;
}

