<?php
ob_start();
define("getsim","5881721407:AAHzqtIin8zBmFtQ3V6aenw5GzyoI-zK84s");
$aaa = "Nosir_okee";
$botname = bot('getme',['bot'])->result->username;
$admin=array("936754197","5267471008");

function addstat($id){
    $check = file_get_contents("getsim.bot");
    $rd = explode("\n",$check);
    if(!in_array($id,$rd)){
        file_put_contents("getsim.bot","\n".$id,FILE_APPEND);
    }
}

function banstat($id){
    $check = file_get_contents("getsim.ban");
    $rd = explode("\n",$check);
    if(!in_array($id,$rd)){
        file_put_contents("getsim.ban","\n".$id,FILE_APPEND);
    }
}

function step($id,$value){
file_put_contents("getsim/$id.step","$value");
}

function stepbot($id,$value){
file_put_contents("getsimbot/$id.step",$value);
}

function typing($chatid){ 
return getsim("sendChatAction",[
"chat_id"=>$chatid,
"action"=>"typing",
]);
}

function reyting(){
    $text = "🏆 <b>TOP 15 ta eng koʻp <b>₽</b> foydalanuvchilar:</b>\n\n";
    $daten = [];
    $rev = [];
    $fayllar = glob("./getsim/*.*");
    foreach($fayllar as $file){
        if(mb_stripos($file,".pul")!==false){
        $value = file_get_contents($file);
        $id = str_replace(["./getsim/",".pul"],["",""],$file);
        $daten[$value] = $id;
        $rev[$id] = $value;
        }
        echo $file;
    }

    asort($rev);
    $reversed = array_reverse($rev);
    for($i=0;$i<15;$i+=1){
        $order = $i+1;
        $id = $daten["$reversed[$i]"];
        $text.= "<b>{$order}</b>. <a href='tg://user?id={$id}'>{$id}</a> - "."<code>".$reversed[$i]."</code>"." <b>₽</b>"."\n";
    }
    return $text;
}

function joinchat($id){
     global $message_id,$referalsum,$firstname;
     $ch1 = file_get_contents("ch1.txt");
     $ret = getsim("getChatMember",[
         "chat_id"=>"@".$ch1."",
         "user_id"=>$id,
         ]);
$stat = $ret->result->status;
$ch2 = file_get_contents("ch2.txt");
$rets = getsim("getChatMember",[
         "chat_id"=>"@".$ch2."",
         "user_id"=>$id,
         ]);
$stats = $rets->result->status;
         if((($stat=="creator" or $stat=="administrator" or $stat=="member") and ($stats=="creator" or $stats=="administrator" or $stats=="member"))){
      return true;
         }else{
     getsim("sendMessage",[
         "chat_id"=>$id,
         "text"=>"<b>Quyidagi kanallarimizga obuna boʻling. Botni keyin toʻliq ishlatishingiz mumkin!</b>",
         "parse_mode"=>"html",
         "reply_to_message_id"=>$message_id,
"disable_web_page_preview"=>true,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"➕ Obuna bo‘lish","url"=>"https://t.me/".$ch1.""],],
[["text"=>"➕ Obuna bo‘lish","url"=>"https://t.me/".$ch2.""],],
[["text"=>"✅ Tasdiqlash","callback_data"=>"result"],],
]
]),
]);  
sleep(0);
     if(file_exists("getsim/".$id.".referalid")){
           $file =  file_get_contents("getsim/".$id.".referalid");
           $get =  file_get_contents("getsim/".$id.".channel");
           if($get=="true"){
            file_put_contents("getsim/".$id.".channel","failed");
            $minimal = $referalsum / 2;
            $user = file_get_contents("getsim/".$file.".pul");
            $user = $user - $minimal;
            file_put_contents("getsim/".$file.".pul","$user");
             getsim("sendMessage",[
             "chat_id"=>$file,
             "text"=>"<b>Sizning do'stingiz</b>, <a href='tg://user?id=".$id."'>".$firstname."</a> <b>bizning kanallarimizdan chiqib ketgani uchun sizga ".$minimal." ₽ jarima berildi.</b>",
             "parse_mode"=>"html",
             "reply_markup"=>$menu,
             ]);
           }
         }  
return false;
}
}

function phonenumber($id){
     $phonenumber = file_get_contents("getsim/$id.contact");
      if($phonenumber==true){
      return true;
         }else{
     stepbot($id,"request_contact");
     getsim("sendPhoto",[
    "chat_id"=>$id,
"photo"=>"https://t.me/FaqatTeslarr/2",
    "caption"=>"Iltimos, Telefon raqamingizni yuboring:",
    "parse_mode"=>"html",
    "reply_markup"=>json_encode([
      "resize_keyboard"=>true,
      "one_time_keyboard"=>true,
      "keyboard"=>[
        [["text"=>"📲 Telefon raqamni yuborish","request_contact"=>true],],
]
]),
]);  
return false;
}
}



function getsim($method,$datas=[]){
    $url = "https://api.telegram.org/bot".getsim."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$callbackdata = $update->callback_query->data;
$chatid = $message->chat->id;
$chat_id = $update->callback_query->message->chat->id;
$messageid = $message->message_id;
$id = $update->callback_query->id;
$fromid = $message->from->id;
$from_id = $update->callback_query->from->id;
$firstname = $message->from->first_name;
$first_name = $update->callback_query->from->first_name;
$lastname = $message->from->last_name;
$message_id = $update->callback_query->message->message_id;
$text = $message->text;
$contact = $message->contact;
$contactid = $contact->user_id;
$contactuser = $contact->username;
$contactname = $contact->first_name;
$phonenumber = $contact->phone_number;
$messagereply = $message->reply_to_message->message_id;
$user = $message->from->username;
$userid = $update->callback_query->from->username;
$query = $update->inline_query->query;
$inlineid = $update->inline_query->from->id;
$messagereply = $message->reply_to_message->message_id;
$soat = date("H:i:s",strtotime("2 hour")); 
$sana = date("d-M Y",strtotime("2 hour"));
$resultid = file_get_contents("getsim.bot");
$ban = file_get_contents("getsim/$chatid.ban");
$banid = file_get_contents("getsim/$chat_id.ban");
$sabab = file_get_contents("getsim/$chat_id.sabab");
$contact = file_get_contents("getsim/$chatid.contact");
$minimalsumma = file_get_contents("getsim/minimal.sum");
$sum = file_get_contents("getsim/$chatid.pul");
$sumid = file_get_contents("getsim/$chat_id.pul");
$jami = file_get_contents("getsim/summa.text");
$referal = file_get_contents("getsim/$chatid.referal");
$referalcallback = file_get_contents("getsim/$chat_id.referal");
$click = file_get_contents("getsim/$chatid.karta");
$paynet = file_get_contents("getsim/$chatid.paynet");
$click = file_get_contents("getsim/$chatid.click");
$referalsum = file_get_contents("getsim/referal.sum");
if(file_get_contents("getsim/minimal.sum")){
}else{    file_put_contents("getsim/minimal.sum","10000");
}
if(file_get_contents("getsim/$chatid.referal")){
}else{    file_put_contents("getsim/$chatid.referal","0");
}
if(file_get_contents("getsim/$chat_id.referal")){
}else{    file_put_contents("getsim/$chat_id.referal","0");
}
if(file_get_contents("getsim/summa.text")){
}else{    file_put_contents("getsim/summa.text","0");
}
if(file_get_contents("getsim/referal.sum")){
}else{    file_put_contents("getsim/referal.sum","0");
}
if(file_get_contents("getsim/$chatid.pul")){
}else{    file_put_contents("getsim/$chatid.pul","0");
}
if(file_get_contents("getsim/$chat_id.pul")){
}else{    file_put_contents("getsim/$chat_id.pul","0");
}
if(file_get_contents("getsim/$chat_id.sabab")){
}else{    file_put_contents("getsim/$chat_id.sabab","Botdan faqat O'zbekiston fuqarolari foydalanishi mumkin!");
}
$step = file_get_contents("getsim/$chatid.step");
$step = file_get_contents("getsimbot/$chatid.step");
mkdir("getsim");
mkdir("getsimbot");
if(!is_dir("getsim")){
  mkdir("getsim");
}

//Bu Bot Kodini @UzPhpKod Kanali Orqali Taratim
//GetSim_Bot ni Asl Kodi Faqat Qiwi Avto Tulov olib tashlangan
//Dasturchi @Xasanov_Otabek
//Manbaga Tegma Ereke Bulsang Am Bulsang Tegaver Ruxsat



$menu = json_encode([
"resize_keyboard"=>true,
    "keyboard"=>[
[["text"=>"🔢 Nomer olish"],["text"=>"👔 Kabinet"]],
[["text"=>"💵 ₽ ishlash"],["text"=>"📞 Murojaat"],],
]
]);

$panel = json_encode([
"resize_keyboard"=>true,
    "keyboard"=>[
[["text"=>"📤 Pochta tizimi"],['text'=>"📢 Kanallar boshqaruvi"]],
[["text"=>"💳 Balans boshqaruvi"],["text"=>"🔧 Narxlarni sozlash"],],
[["text"=>"🚫 Taqiqlar muharriri"],["text"=>"📊 Statistika"],],
[['text'=>"💵 Hisob"],['text'=>"🏆 Reyting"]],
[['text'=>"🔓 Yoqish"],['text'=>"🔐 O`chirish"]],
[["text"=>"🔙 Orqaga"],],
]
]);

$pochta = json_encode([
"resize_keyboard"=>true,
    "keyboard"=>[
[["text"=>"📢 Xabar tarqatish"],],
[["text"=>"🔙 Admin paneli"],],
]
]);

$balans_manager = json_encode([
"resize_keyboard"=>true,
    "keyboard"=>[
[["text"=>"💳 Hisob tekshirish"]],
[["text"=>"💳 Hisob toʻldirish"],["text"=>"💳 Hisob ayirish"],],
[["text"=>"🔙 Admin paneli"],],
]
]);

$channel_manager = json_encode([
"resize_keyboard"=>true,
    "keyboard"=>[
[["text"=>"🗄 Majburiy obuna"],],
[["text"=>"🔙 Admin paneli"],],
]
]);

$narx_manager = json_encode([
"resize_keyboard"=>true,
    "keyboard"=>[
[["text"=>"👥 Taklif narxi"]],
[["text"=>"🔙 Admin paneli"],],
]
]);

$ban_manager = json_encode([
"resize_keyboard"=>true,
    "keyboard"=>[
[["text"=>"🚫 Taqiq qoʻyish"],["text"=>"➖ Taqiqdan olish"],],
[["text"=>"🔙 Admin paneli"],],
]
]);

$servis=json_encode([
'inline_keyboard'=>[
[['text'=>"🇺🇿 O‘zbekiston",'callback_data'=>"uzb"]],
[['text'=>"🇷🇺 Rossiya",'callback_data'=>"rus"],['text'=>"🇻🇳 Vietnam",'callback_data'=>"vit"]],
[['text'=>"🇨🇳 Xitoy",'callback_data'=>"chin"]],
]
]);

$back = json_encode([
 "one_time_keyboard"=>true,
"resize_keyboard"=>true,
    "keyboard"=>[
[["text"=>"🔙 Orqaga"],],
]
]);

if(($step=="request_contact") and ($ban==false) and (isset($phonenumber))){
$phonenumber = str_replace("+","","$phonenumber");
if(joinchat($fromid)=="true"){
if((strlen($phonenumber)==12) and (stripos($phonenumber,"998")!==false)){
if($contactid==$chatid){
addstat($fromid);
if($user){
$username = "@$user";
}else{
$username = "$firstname";
}
if(file_exists("getsim/".$fromid.".referalid")){
$referalid = file_get_contents("getsim/".$fromid.".referalid"); 
$channel = file_get_contents("getsim/".$fromid.".channel");
$conts = file_get_contents("getsim/".$fromid.".login");
if($channel=="true" and $conts=="false"){
if(joinchat($referalid)=="true"){
file_put_contents("getsim/".$fromid.".login","true");
getsim("deleteMessage",[
"chat_id"=>$chat_id,
"message_id"=>$message_id,
]);
$user = file_get_contents("getsim/".$referalid.".pul");
$referalsum = $referalsum / 2;
$user = $user + $referalsum;
file_put_contents("getsim/".$referalid.".pul","$user");
$firstname = str_replace(["<",">","/"],["","",""],$firstname);
getsim("sendMessage",[
"chat_id"=>$referalid,
"text"=>"🎉 Siz taklif qilgan <a href='tg://user?id=$fromid'>$firstname</a> botimizdan roʻyhatdan oʻtdi va sizga $referalsum ₽ taqdim etildi!",
"parse_mode"=>"html",
"reply_markup"=>$menu,
]);
}
}
}
$reply = getsim("sendMessage",[
"chat_id"=>$fromid,
"text"=>"🤑 Bot platformasidan ₽ ishlang va nomer oling!",
"parse_mode"=>"html",
"reply_markup"=>$menu,
])->result->message_id;
getsim("sendMessage",[
"chat_id"=>$fromid,
"text"=>"🗄 Kerakli panelni tanlang:",
"parse_mode"=>"html",
"reply_to_message_id"=>$reply,
"disable_web_page_preview"=>true,
]);
unlink("getsimbot/$chatid.step");
file_put_contents("getsim/$chatid.contact","$phonenumber");
}else{
  addstat($chatid);
  getsim("sendMessage",[
    "chat_id"=>$chatid,
    "text"=>"🗄 Faqat oʻzingizni raqamingizni yuboring:",
    "parse_mode"=>"html",
    "reply_markup"=>json_encode([
      "resize_keyboard"=>true,
      "one_time_keyboard"=>true,
      "keyboard"=>[
        [["text"=>"📲 Telefon raqamni yuborish","request_contact"=>true],],
]
]),
]);
}
}else{
  banstat($chatid);
  getsim("sendMessage",[
    "chat_id"=>$chatid,
    "text"=>"❗ Kechirasiz, bu bot faqat Oʻzbekiston fuqarolari uchun!

Iltimos, Oʻzbekitondagi hisobingizdan foydalaning!",
    "parse_mode"=>"html",
    "reply_to_message_id"=>$messageid,
    "reply_markup"=>json_encode([
    "remove_keyboard"=>true,
    ]),
  ]);
unlink("getsimbot/$chatid.step");
file_put_contents("getsim/$chatid.ban","ban");
}
}
}

if($text=="🏆 Reyting"and in_array($chatid,$admin)){
getsim('sendMessage',[
'chat_id'=>$chatid,
'text'=>reyting(),
'parse_mode'=>"HTML",
]);
}

if($text=="/panel" and in_array($chatid,$admin)){
typing($chatid);
getsim('sendMessage',[
"chat_id"=>$chatid,
"text"=>"🔧 Siz admin panelidasiz.

✅ Barcha uskunalar sizni kutmoqda:",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

if($text=="🔙 Admin paneli" and in_array($chatid,$admin)){
    typing($chatid);
    getsim("sendMessage",[
    "chat_id"=>$chatid,
    "text"=>"🗄 Admin paneli",
    "parse_mode"=>"html",
    "reply_markup"=>$panel,
    ]);
unlink("setkanal.txt");
unlink("getsimbot/$chatid.step");
    }


$setkanal=file_get_contents("setkanal.txt");
if($text == "1️⃣-Kanal" and in_array($chatid,$admin)){
    getsim('sendMessage',[
    'chat_id'=>$chatid,
    'text'=>"• Koʻrsatma boʻyicha kanalingizni kiriting:
    Masalan: @ProKometa
    
    
    ❕Ushbu xabar botga yuborilsa 1-kanalga @ProKometa kanali ulanadi.
    "
        ]);
        file_put_contents("setkanal.txt","1");
    }

    if($text == "2️⃣-Kanal" and in_array($chatid,$admin)){
        getsim('sendMessage',[
        'chat_id'=>$chatid,
        'text'=>"• Koʻrsatma boʻyicha kanalingizni kiriting:
        Masalan: @ProKometa
        
        
        ❕Ushbu xabar botga yuborilsa 2-kanalga @ProKometa kanali ulanadi.
        "
            ]);
            file_put_contents("setkanal.txt","2");
        }
    


        if($text=="🗄 Majburiy obuna" and in_array($chatid,$admin)){
    getsim('sendMessage',[
        'chat_id'=>$chatid,
        'text'=>"siz botga bir vaqtning ozida 3tagacha kanal ulash imkoni mavjud kanballardan birini tanlang",
        'reply_markup'=>json_encode([
            'resize_keyboard'=>true,
            'keyboard'=>[
                [['text'=>"1️⃣-Kanal"],['text'=>"2️⃣-Kanal"]],
                [['text'=>"🔙 Admin paneli"],],
            ]]),
    ]);
}
    
$status=file_get_contents("on.txt");
            
if($text=="🔓 Yoqish" and in_array($chatid,$admin)){
getsim('sendMessage',[
'chat_id'=>$chatid,
'text'=>"yoqildi",
]);
file_put_contents("on.txt","on");
}

if($text=="🔐 O`chirish" and in_array($chatid,$admin)){
getsim('sendMessage',[
'chat_id'=>$chatid,
'text'=>"O`chirildi",
]);
unlink("on.txt");
}

if(mb_stripos($text, "@")!==false and $setkanal=="1"){
	$m1 = explode("@",$text);
 $m2 = $m1[1];
 file_put_contents("ch1.txt","$m2");
 getsim('sendMessage',[
'chat_id'=>$chatid,
'text'=>"1-kanal @$m2 kanaliga oʻzgardi!",
 ]); unlink("setkanal.txt");
}



if(mb_stripos($text, "@")!==false and $setkanal=="2"){
	$m1 = explode("@",$text);
 $m2 = $m1[1];
 file_put_contents("ch2.txt","$m2");
 getsim('sendMessage',[
'chat_id'=>$chatid,
'text'=>"2-kanal @$m2 kanaliga oʻzgardi!",
 ]); unlink("setkanal.txt");
}


//Bu Bot Kodini @UzPhpKod Kanali Orqali Taratim
//GetSim_Bot ni Asl Kodi Faqat Qiwi Avto Tulov olib tashlangan
//Dasturchi @Xasanov_Otabek
//Manbaga Tegma Ereke Bulsang Am Bulsang Tegaver Ruxsat




if($text=="💳 Balans boshqaruvi" and in_array($chatid,$admin)){
typing($chatid);
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"💳 Balansni boshqarish rejimi:",
"parse_mode"=>"html",
"reply_markup"=>$balans_manager,
]);
}



if($text=="📤 Pochta tizimi" and in_array($chatid,$admin)){
typing($chatid);
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"📤 Pochta tizimi sizga foydalanuvchilarga pochta tarqatishga yordam beradi.

Pochta tizimi orqali xabarlarni tarqating:",
"parse_mode"=>"html",
"reply_markup"=>$pochta,
]);
}



if($text=="📢 Kanallar boshqaruvi" and in_array($chatid,$admin)){
typing($chatid);
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"📢 Ushbu boʻlim sizga botning shaxsiy kanallarini qoʻshishga yordam beradi.

Kanallarni targʻib qiling:",
"parse_mode"=>"html",
"reply_markup"=>$channel_manager,
]);
}



if($text=="🔧 Narxlarni sozlash" and in_array($chatid,$admin)){
typing($chatid);
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"🔧 Ushbu uskuna botdagi daromad narxlarini targʻib qiladi.

Narxlarni sozlash uchun buyruqlardan foydalaning:",
"parse_mode"=>"html",
"reply_markup"=>$narx_manager,
]);
}



if($text=="🚫 Taqiqlar muharriri" and in_array($chatid,$admin)){
typing($chatid);
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"🚫 Taqiqlar muharriri orqali foydalanuvchilarga taqiq qoʻying va qoʻyilgan taqiqdan ozod eting.

Taqiqni boshqarish uchun buyruqlardan foydalaning:",
"parse_mode"=>"html",
"reply_markup"=>$ban_manager,
]);
}

if($text=="📢 Xabar tarqatish" and in_array($chatid,$admin)){
    stepbot($chatid,"send_post");
typing($chatid);
      getsim("sendMessage",[
      "chat_id"=>$chatid,
      "text"=>"📝 Rasmli xabar matnini kiriting:",
      "parse_mode"=>"html",
          ]);
            }
     if($step=="send_post"){
        $file_id = $message->photo[0]->file_id;
        $caption = $message->caption;
                $ok = getsim("sendPhoto",[
                  "chat_id"=>$chatid,
                  "photo"=>$file_id,
                  "caption"=>$caption,
                ]);
                if($ok->ok){
                  getsim("sendPhoto",[
                    "chat_id"=>$chatid,
                    "photo"=>$file_id,
                      "caption"=>"$caption\n\nYaxshi, rasmni qabul qildim!\nEndi tugmani na‘muna bo'yicha joylang.\n
<pre>[GetSim_Bot+https://t.me/getsim_bot]\n[Yangiliklar+https://t.me/getsimuz]</pre>",
"parse_mode"=>"html",
                      "disable_web_page_preview"=>true,
                    ]);
             file_put_contents("getsimbot/$chatid.text","$file_id{set}$caption");
             stepbot($chatid,"xabar_tugma");
         }
     }
     
    if($step=="xabar_tugma"){
      $xabar = getsim("sendMessage",[
        "chat_id"=>$chatid,
        "text"=>"Connections...",
      ])->result->message_id;
      getsim("deleteMessage",[
        "chat_id"=>$chat_id,
        "message_id"=>$xabar,
      ]);
   $usertext = file_get_contents("getsimbot/$chatid.text");
   $fileid = explode("{set}",$usertext);
   $file_id = $fileid[0];
   $caption = $fileid[1];
       preg_match_all("|\[(.*)\]|U",$text,$ouvt);
$keyboard = [];
foreach($ouvt[1] as $ouut){
$ot = explode("+",$ouut);
array_push($keyboard,[["url"=>"$ot[1]", "text"=>"$ot[0]"],]);
}
$ok = getsim("sendPhoto",[
"chat_id"=>$chatid,
"photo"=>$file_id,
"caption"=>"Sizning rasmingiz ko‘rinishi:\n\n".$caption,
"parse_mode"=>"html",
"reply_markup"=>json_encode(
["inline_keyboard"=>
$keyboard
]),
]);
if($ok->ok){
$userlar = file_get_contents("getsim.bot");
$count = substr_count($userlar,"\n");
$count_member = count(file("getsim.bot"))-1;
  $ids = explode("\n",$userlar);
  foreach ($ids as $line => $id) {
    $clear = getsim("sendPhoto",[
"chat_id"=>$id,
"photo"=>$file_id,
"caption"=>$caption,
"disable_web_page_preview"=>true,
"reply_markup"=>json_encode(
["inline_keyboard"=>
$keyboard
]),
]);
unlink("getsimbot/$chatid.step");
}

if($clear){
$userlar = file_get_contents("getsim.bot");
$count = substr_count($userlar,"\n");
$count_member = count(file("getsim.bot"))-1;
  getsim("sendMessage",[
    "chat_id"=>$chatid,
    "text"=>"Xabar <b>$count_member</b> foydalanuvchilarga yuborildi!",
    "parse_mode"=>"html",
  ]);
}
}else{
  getsim("sendMessage",[
    "chat_id"=>$chatid,
    "text"=>"Tugmani kiritishda xato bor. Iltimos, qaytadan yuboring:",
  ]);
unlink("getsimbot/$chatid.step");  
}
}



if($text=="💳 Hisob tekshirish" and in_array($chatid,$admin)){
typing($chatid);
stepbot($chatid,"result");
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"Foydalanuvchini ID raqamini kiriting:",
"parse_mode"=>"html",
]);
}


if($step=="result"){
typing($chatid);
if($text=="🔙 Admin paneli" or $text=="💳 Hisob tekshirish" or $text=="💳 Hisob toʻldirish"){
}else{
$sum = file_get_contents("getsim/$text.pul");
$referal = file_get_contents("getsim/$text.referal");
$raqam = file_get_contents("getsim/$text.contact");
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"<b>Foydalanuvchi hisobi:</b> <code>$sum</code>\n<b>Foydalanuvchi referali:</b> <code>$referal</code>\n<b>Foydalanuvchi raqami:</b> <code>$raqam</code>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);unlink("getsimbot/$chatid.step");
}
}


if($text=="💳 Hisob toʻldirish" and in_array($chatid,$admin)){
typing($chatid);
stepbot($chatid,"coin");
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"Foydalanuvchi hisobini nechi sumga toʻldirmoqchisiz:",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}


if($step=="coin"){
typing($chatid);
file_put_contents("getsim/$chatid.coin",$text);
if($text=="🔙 Admin paneli" or $text=="💳 Hisob tekshirish" or $text=="💳 Hisob toʻldirish"){
}else{
stepbot($chatid,"pay");
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"Foydalanuvchi ID raqamini kiriting:",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}
}

if($step=="pay"){
typing($chatid);
if($text=="🔙 Admin paneli" or $text=="💳 Hisob tekshirish" or $text=="💳 Hisob toʻldirish"){
}else{
$summa = file_get_contents("getsim/$chatid.coin");
$sum =  file_get_contents("getsim/$text.pul");
$jami = $sum + $summa;
file_put_contents("getsim/$text.pul","$jami");
getsim("sendMessage",[
   "chat_id"=>$text,
          "text"=>"💰 Sizning hisobingiz admin tomonidan $summa sumga toʻldirildi!

Hozirgi hisobingiz: $jami sum",
]);
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"✅ Foydalanuvchi balansi toʻldirildi!",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("getsimbot/$chatid.step");
}
}


if($text=="💳 Hisob ayirish" and in_array($chatid,$admin)){
typing($chatid);
stepbot($chatid,"pcoin");
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"Foydalanuvchi hisobidan qancha olish kerak",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}


if($step=="pcoin"){
typing($chatid);
file_put_contents("getsim/$chatid.coin",$text);
if($text=="🔙 Admin paneli" or $text=="💳 Hisob tekshirish" or $text=="💳 Hisob toʻldirish"){
}else{
stepbot($chatid,"pminus");
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"Foydalanuvchi ID raqamini kiriting:",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}
}

if($step=="pminus"){
typing($chatid);
if($text=="🔙 Admin paneli" or $text=="💳 Hisob tekshirish" or $text=="💳 Hisob toʻldirish"){
}else{
$summa = file_get_contents("getsim/$chatid.coin");
$sum =  file_get_contents("getsim/$text.pul");
$jami = $sum - $summa;
file_put_contents("getsim/$text.pul","$jami");
getsim("sendMessage",[
   "chat_id"=>$text,
          "text"=>"",
]);
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"✅ Foydalanuvchi hisobi ayrildi",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("getsimbot/$chatid.step");
}
}
if($text=="👥 Taklif narxi" and in_array($chatid,$admin)){
typing($chatid);
stepbot($chatid,"referal");
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"Yangi taklif narxini kiriting:",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

if($text=="💵 Hisob" and in_array($chatid,$admin)){
$ap=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=balance&id=admin"),1)['balance'];
getsim('sendMessage',[
'chat_id'=>$chatid,
'text'=>"💵 Hisobda: $ap ₽",
]);}

if($step=="referal"){
typing($chatid);
if($text=="🔙 Admin paneli" or $text=="👥 Taklif narxi" or $text=="📤 Minimal narx"){
}else{
file_put_contents("getsim/referal.sum","$text");
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"✅ Taklif narxi $text ₽ga oʻzgardi!",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("getsimbot/$chatid.step");
}
}

if($text=="/set"){
$i=file_get_contents("getsim.bot");
$i=str_replace("n","\n",$i);
$ok=file_put_contents("getsim.bot",$i);
getsim('sendMessage',[
'chat_id'=>$chatid,
'text'=>"ok $ok",
]);
}

if($text=="➖ Taqiqdan olish" and in_array($chatid,$admin)){
stepbot($chatid,"unban");
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"Foydalanuvchini ID raqamini kiriting:",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}

//Bu Bot Kodini @UzPhpKod Kanali Orqali Taratim
//GetSim_Bot ni Asl Kodi Faqat Qiwi Avto Tulov olib tashlangan
//Dasturchi @Xasanov_Otabek
//Manbaga Tegma Ereke Bulsang Am Bulsang Tegaver Ruxsat

if($step=="unban"){
unlink("getsim/$text.ban");
if($text=="🔙 Admin paneli" or $text=="🚫 Taqiq qoʻyish" or $text=="➖ Taqiqdan olish"){
}else{
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"<a href='tg://user?id=$text'>Foydalanuvchi</a> <b>bandan olindi!</b>",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("getsimbot/$chatid.step");
}
}


if($text=="🚫 Taqiq qoʻyish" and in_array($chatid,$admin)){
stepbot($chatid,"sabab");
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"🚫 Foydalanuvchiga nima sababdan taqiq qoʻymoqchisiz:",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
}


if($step=="sabab"){
file_put_contents("getsim/$chatid.sabab","$text");
getsim("sendMessage",[
"chat_id"=>$admin,
"text"=>"Foydalanuvchini ID raqamini kiriting:",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
stepbot($chatid,"ban");
}

if($step=="ban"){
banstat($text);
$sabab = file_get_contents("getsim/$chatid.sabab");
file_put_contents("getsim/$text.sabab","$sabab");
file_put_contents("getsim/$text.ban","ban");
if($text=="🔙 Admin paneli" or $text=="🚫 Taqiq qoʻyish" or $text=="➖ Taqiqdan olish"){
}else{
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"<a href='tg://user?id=$text'>Foydalanuvchiga</a> taqiq qoʻyildi.",
"parse_mode"=>"html",
"reply_markup"=>$panel,
]);
unlink("getsimbot/$chatid.step");
getsim("sendMessage",[
"chat_id"=>$text,
"text"=>"❗ Hurmatli foydalanuvchi! Sizga botda taqiq qoʻyildi. Shu sababdan bot siz uchun yopiq!",
"parse_mode"=>"html",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"📃 Batafsil maʼlumot","callback_data"=>"sabab"],],
]
]),
]);
}
}



if($callbackdata=="back" and $banid==false){
if((joinchat($from_id)=="true") and (phonenumber($from_id)=="true") and ($banid==false)){
getsim("deleteMessage",[
"chat_id"=>$chat_id,
"message_id"=>$message_id,
]);
getsim("sendMessage",[
"chat_id"=>$chat_id,
"text"=>"🏠 Bosh sahifa",
"parse_mode"=>"html",
"reply_markup"=>$menu,
]);
}
}



if($text=="💵 ₽ ishlash" and $ban==false){

if((joinchat($fromid)=="true") and (phonenumber($fromid)=="true") and ($ban==false)){
if($user){
$username = "@$user";
}else{
$username = "$firstname";
}
getsim("sendMessage",[
    "chat_id"=>$chatid,
    "text"=>"✅ Vertual nomer olish uchun moʻljallangan Bot!

$username doʻstingizdan taklif havolasi! Boshlash uchun bosing:
https://t.me/$botname?start=$chatid",
"parse_mode"=>"html",
"disable_web_page_preview"=>true,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"↗️ Doʻstlarga yuborish","switch_inline_query"=>$chatid],],
]
]),
]);
}
}

if($text=="👔 Kabinet" and $ban==false){
if((joinchat($fromid)=="true") and (phonenumber($fromid)=="true") and ($ban==false)){
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"
Sizning hisobingiz: <code>$sum</code> ₽
Taklifingiz: <code>$referal</code> ta",
"parse_mode"=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"💵 Hisob to`ldirish",'callback_data'=>"pay"]],
]
]),
]);
}
}

if($callbackdata=="pay"){
if((joinchat($from_id)!=="true") and (phonenumber($from_id)!=="true") and ($banid==false)){
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"💳 Hisobni to’ldirish usulini tanlang",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🥝 QIWI (AVTO)",'callback_data'=>"k"],['text'=>"💠 CLICK",'callback_data'=>"cl"]],
]
]),
]);
}
}

if($callbackdata=="k"){
if((joinchat($from_id)!=="true") and (phonenumber($from_id)!=="true") and ($banid==false)){
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
💳 Hisobni to’ldirish Qiwi
📱Hamyon: `+998902892870`
💬 Izoxga `$from_id`",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"💠 CLICK",'callback_data'=>"cl"]],
]
]),
]);
}
}

if($callbackdata=="cl"){
if((joinchat($from_id)!=="true") and (phonenumber($from_id)!=="true") and ($banid==false)){
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"💳 Hisobni to’ldirish Click
📱Hamyon: `8801 7082 1594 9322`",
'parse_mode'=>"markdown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🥝 QIWI (AVTO)",'callback_data'=>"k"]],
]
]),
]);
}
}

if($text=="🔙 Orqaga" and $ban==false){
if((joinchat($fromid)=="true") and (phonenumber($fromid)=="true") and ($ban==false)){
addstat($chatid);
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"🏠 Bosh sahifa",
"parse_mode"=>"html",
"reply_markup"=>$menu,
]);
unlink("getsim/$chatid.step");
unlink("getsimbot/$chatid.step");
}
}

if((stripos($text,"/start")!==false) && ($ban==false)){
if((joinchat($fromid)=="true") and (phonenumber($fromid)=="true") and ($ban==false)){
addstat($fromid);
if($user){
$username = "@$user";
}else{
$username = "$firstname";
}
$reply = getsim("sendMessage",[
"chat_id"=>$fromid,
"text"=>"🤑 Bot platformasida ₽ ishlang va nomer oling!",
"parse_mode"=>"html",
"reply_markup"=>$menu,
])->result->message_id;
getsim("sendMessage",[
"chat_id"=>$fromid,
"text"=>"✅ Kerakli panelni tanlang:",
"parse_mode"=>"html",
"reply_to_message_id"=>$reply,
"disable_web_page_preview"=>true,
]);
}
}

if((stripos($text,"/start")!==false) && ($ban==false)){
$public = explode("*",$text);
$refid = explode(" ",$text);
$refid = $refid[1];
if(strlen($refid)>0){
$idref = "getsim/$refid.id";
$idrefs = file_get_contents($idref);
$userlar = file_get_contents("getsim.bot");
$explode = explode("n",$userlar);
if(!in_array($chatid,$explode)){
file_put_contents("getsim.bot","n".$chatid,FILE_APPEND);
}
if($refid==$chatid and $ban==false){
      getsim("sendMessage",[
      "chat_id"=>$chatid,
      "text"=>"☝️ <b>Hurmatli foydalanuvchi!</b>

Botga o'zingizni taklif qila olmaysiz!",
      "parse_mode"=>"html",
      "reply_to_message_id"=>$messageid,
      ]);
      }else{
    if((stripos($userlar,"$chatid")!==false) and ($ban==false)){
      getsim("sendMessage",[
      "chat_id"=>$chatid,
      "text"=>"<b>Hurmatli foydalanuvchi!</b>

Doʻstingiz sizni taklif qila olmaydi!",
"parse_mode"=>"html",
"reply_to_message_id"=>$messageid,
]);
}else{
$id = "$chatidn";
$handle = fopen("$idref","a+");
fwrite($handle,$id);
fclose($handle);
file_put_contents("getsim/$fromid.referalid","$refid");
file_put_contents("getsim/$fromid.channel","false");
file_put_contents("getsim/$fromid.login","false");
      getsim("sendMessage",[
      "chat_id"=>$refid,
"text"=>"👏 Siz taklif qilgan <a href='tg://user?id=$fromid'>$firstname</a> botimizga qoʻshildi. Doʻstingiz kanallarimizga qoʻshilgandan soʻng sizga taklif uchun ₽ taqdim etiladi!",
"parse_mode"=>"html",
]);
}
}
}
}

if($callbackdata=="result" and ($banid==false)){
addstat($from_id);
if((joinchat($from_id)=="true")  and ($banid==false)){
if(phonenumber($from_id)=="true"){
if($userid==true){
$result = "@$userid";
}else{
$result = "$first_name";
}
getsim("deleteMessage",[
"chat_id"=>$from_id,
"message_id"=>$message_id,
]);
$reply = getsim("sendMessage",[
"chat_id"=>$from_id,
"text"=>"🤑 Bot platformasida ₽ ishlang va nomer oling!",
"parse_mode"=>"html",
"reply_markup"=>$menu,
])->result->message_id;
getsim("sendMessage",[
    "chat_id"=>$from_id,
    "text"=>"✅ Kerakli panelni tanlang:",
"parse_mode"=>"html",
"reply_to_message_id"=>$reply,
"disable_web_page_preview"=>true,
]);
}
$time =  microtime(true);
$random  = rand(999999,3456789);
usleep($random);
$current  = microtime(true)-$time;
usleep($current);
if($referalsum==true){
if(file_exists("getsim/".$from_id.".referalid")){
$referalid = file_get_contents("getsim/".$from_id.".referalid");
if(joinchat($referalid)=="true"){
$is_user = file_get_contents("getsim/".$from_id.".channel");
$login = file_get_contents("getsim/".$from_id.".login");
if($is_user=="false" and $login=="false"){
$minimal = $referalsum / 2;
$user = file_get_contents("getsim/".$referalid.".pul");
$user = $user + $minimal;
file_put_contents("getsim/".$referalid.".pul","$user");
$referal = file_get_contents("getsim/".$referalid.".referal");
$referal = $referal + 1;
file_put_contents("getsim/".$referalid.".referal",$referal);
file_put_contents("getsim/".$from_id.".channel","true");
$firstname = str_replace(["<",">","/"],["","",""],$firstname);
getsim("sendMessage",[
"chat_id"=>$referalid,
"text"=>"👏 Tabriklaymiz! Sizning doʻstingiz <a href='tg://user?id=".$from_id."'>".$first_name."</a> kanallarga obuna boʻldi va sizga ".$minimal." ₽ taqdim etildi!
Doʻstingiz roʻyxatdan oʻtsa sizga yana ".$minimal." ₽ taqdim etiladi!",
"parse_mode"=>"html",
"reply_markup"=>$menu,
]);
}
}
}
}
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Siz hali kanallarga obuna boʻlmadingiz!",
"show_alert"=>false,
]);
}
}



if(mb_stripos($query,"$inlineid")!==false){
$user = $update->inline_query->from->username;
$firstname = $update->inline_query->from->first_name;
if($user){
$username = "@$user";
}else{
$username = "$firstname";
}
getsim("answerInlineQuery",[
"inline_query_id"=>$update->inline_query->id,
"cache_time"=>1,
"results"=>json_encode([[
"type"=>"article",
"id"=>base64_encode(1),
"title"=>"🎈 Taklif havolasi",
"description"=>"$username doʻstingizdan taklif havolasi",
"thumb_url"=>"https://yearling-truck.000webhostapp.com/demo/download.png",
"input_message_content"=>[
"disable_web_page_preview"=>true,
"parse_mode"=>"html",
"message_text"=>"Vertual nomer olish uchun moʻljallangan Bot!

$username doʻstingizdan taklif havolasi! Boshlash uchun bosing:
https://t.me/$botname?start=$inlineid"],
"reply_markup"=>[
"inline_keyboard"=>[
[["text"=>"🚀 Boshlash","url"=> "https://t.me/$botname?start=$inlineid"],],
]]
],
])
]);
}


if($text=="📊 Statistika" and $ban==false){
if((joinchat($fromid)=="true") and (phonenumber($fromid)=="true") and ($ban==false)){
$userlar = file_get_contents("getsim.bot");
$count = substr_count($userlar,"n");
$member = count(file("getsim.bot"))-1;
$banusers = file_get_contents("getsim.ban");
$bancount = substr_count($userlar,"n");
$banmember = count(file("getsim.ban"))-1;
    getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"
Bot foydalanuvchilari: <code>$member</code> ta
Taqiq olganlar: <code>$banmember</code> ta
Taklifingiz: <code>$referal</code> ta

$sana-$soat",
"parse_mode"=>"html",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"♻️ Yangilash","callback_data"=>"upgrade"],],
]
]),
]);
}
}

if($callbackdata=="upgrade" and $banid==false){
if((joinchat($from_id)=="true") and (phonenumber($from_id)=="true") and ($banid==false)){
$referal = file_get_contents("getsim/$chat_id.referal");
$userlar = file_get_contents("getsim.bot");
$count = substr_count($userlar,"n");
$member = count(file("getsim.bot"))-1;
$banusers = file_get_contents("getsim.ban");
$bancount = substr_count($userlar,"n");
$banmember = count(file("getsim.ban"))-1;
getsim("editMessageText",[
"chat_id"=>$chat_id,
"message_id"=>$message_id,
"text"=>"Bot foydalanuvchilari: $member ta
Taqiq olganlar: $banmember ta
Taklifingiz: $referal ta

$sana-$soat",
"parse_mode"=>"html",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"♻️ Yangilash","callback_data"=>"upgrade"],],
]
]),
]);
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Bot foydalanuvchilari: $member ta
Taqiq olganlar: $banmember ta
Taklifingiz: $referal ta

$sana-$soat",
"show_alert"=>true,
]);
}
}

if($text=="📞 Murojaat" and $ban==false){

if((joinchat($fromid)=="true") and (phonenumber($fromid)=="true") and ($ban==false)){
getsim("sendMessage",[
   "chat_id"=>$chatid,
   "text"=>"
Oʻz murojaatlaringizni bot adminiga yetkazing!

Aloqa admini: @$aaa",
"parse_mode"=>"html",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"🗣 Bog'lanish","url"=>"https://t.me/$aaa"],],
]
]),
]);
}
}

if($text=="🔢 Nomer olish") {
if((joinchat($fromid)=="true") and (phonenumber($fromid)=="true") and ($ban==false)){
getsim('sendMessage',[
'chat_id'=>$chatid,
'text'=>"🚀 Nomer olish uchun davlatlar ro'yxati:",
'reply_markup'=>$servis,
]);
}
}

//Bu Bot Kodini @UzPhpKod Kanali Orqali Taratim
//GetSim_Bot ni Asl Kodi Faqat Qiwi Avto Tulov olib tashlangan
//Dasturchi @Xasanov_Otabek
//Manbaga Tegma Ereke Bulsang Am Bulsang Tegaver Ruxsat

if($callbackdata and $status!="on" and $callbackdata!="chin" and $callbackdata!="upgrade" and $callbackdata!="pay" and $callbackdata!="k" and $callbackdata!="cl" and $callbackdata!="back"){
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Nomer olish yopib qoyilgan",
"show_alert"=>true,
]);return false;
}

if($callbackdata=="rus"){
if((joinchat($from_id)=="true") and (phonenumber($from_id)=="true") and ($banid==false)){
$j=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=qiwiwallet"),1);
$j2=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=telegram"),1);
$j3=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=pubg"),1);
$j4=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=google"),1);
$j5=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=instagram"),1);
$j6=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=tiktok"),1);
$j7=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=facebook"),1);
$qi_c=$j['qiwiwallet']['russia']['beeline']['count'];
$tg_c=$j2['telegram']['russia']['mts']['count'];
$pb_c=$j3['pubg']['russia']['beeline']['count'];
$go_c=$j4['google']['russia']['beeline']['count'];
$in_c=$j5['instagram']['russia']['beeline']['count'];
$tt_c=$j6['tiktok']['russia']['beeline']['count'];
$ff_c=$j7['facebook']['russia']['beeline']['count'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
Tarmoqlarni tanlang:
🛎Telegram - $tg_c -ta
🛎Instagram - $in_c -ta
🛎QIWl - $qi_c -ta
🛎Google -$go_c -ta
🛎Pubg - $pb_c-ta
🛎TikTok - $tt_c-ta
🛎Facebook- $ff_c-ta
",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>" 📲 Telegram 21-₽",'callback_data'=>"ru_tg"],['text'=>"🥝 Qiwi 14-₽",'callback_data'=>"ru_qiwi"]],
[['text'=>" 📭  Google 9-₽",'callback_data'=>"ru_gogle"],['text'=>"❤️ Instagram 9-₽",'callback_data'=>"ru_insta"]],
[['text'=>" 🎮 Pubg 5-₽",'callback_data'=>"ru_pubg"],['text'=>"🧡 TikTok 6-₽",'callback_data'=>"ru_tiktok"]],
[['text'=>"🧡 Facebook 15-₽",'callback_data'=>"ru_face"]],
]
]),
]);
}
}
if($callbackdata=="uzb"){
if((joinchat($from_id)=="true") and (phonenumber($from_id)=="true") and ($banid==false)){
$j=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=qiwiwallet"),1);
$j2=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=imo"),1);
$j4=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=google"),1);
$j5=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=instagram"),1);
$j6=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=tiktok"),1);
$j7=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=facebook"),1);
$qi_c=$j['qiwiwallet']['uzbekistan']['virtual21']['count'];
$fc_c=$j7['facebook']['uzbekistan']['virtual23']['count'];
$im_c=$j2['imo']['uzbekistan']['virtual21']['count'];
$go_c=$j4['google']['uzbekistan']['virtual18']['count'];
$in_c=$j5['instagram']['uzbekistan']['virtual23']['count'];
$tt_c=$j6['tiktok']['uzbekistan']['virtual18']['count'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
Tarmoqlarni tanlang:
🛎Imo- $im_c -ta
🛎Instagram - $in_c -ta
🛎QIWl - $qi_c -ta
🛎Google -$go_c -ta
🛎Facebook - $fc_c-ta
🛎TikTok - $tt_c-ta
",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>" 📲 imo 23-₽",'callback_data'=>"uz_imo"],['text'=>"🥝 Qiwi 29-₽",'callback_data'=>"uz_qiwi"]],
[['text'=>" 📭  Google 45-₽",'callback_data'=>"uz_gogle"],['text'=>"❤️ Instagram 34-₽",'callback_data'=>"uz_insta"]],
[['text'=>"💙 Facebook 53-₽",'callback_data'=>"uz_face"],['text'=>"🧡 TikTok 20-₽",'callback_data'=>"uz_tiktok"]],
]
]),
]);
}
}

if($callbackdata=="chin"){
if((joinchat($from_id)=="true") and (phonenumber($from_id)=="true") and ($banid==false)){
$j4=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=google"),1);
$j5=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=instagram"),1);
$j6=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=tiktok"),1);
$j7=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=facebook"),1);
$j8=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=telegram"),1);
$fc_c=$j7['facebook']['china']['virtual4']['count'];
$go_c=$j4['google']['china']['virtual4']['count'];
$in_c=$j5['instagram']['china']['virtual4']['count'];
$tt_c=$j6['tiktok']['china']['virtual4']['count'];
$tg_c=$j8['telegram']['china']['virtual4']['count'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
Tarmoqlarni tanlang:
🛎Telegram- $tg_c -ta
🛎Instagram - $in_c -ta
🛎Google -$go_c -ta
🛎Facebook - $fc_c-ta
🛎TikTok - $tt_c-ta
",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"📲 Telegram 24-₽",'callback_data'=>"chin_tg"]],
[['text'=>" 📭 Google 20-₽",'callback_data'=>"chin_gogle"],['text'=>"❤️ Instagram 20-₽",'callback_data'=>"chin_insta"]],
[['text'=>"💙 Facebook 18-₽",'callback_data'=>"chin_face"],['text'=>"🧡 TikTok 19-₽",'callback_data'=>"chin_tiktok"]],
]
]),
]);
}
}

if($callbackdata=="chin_insta" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=20){
$tg_rue=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=china&product=instagram"),1);
$tg_ru_phone=$tg_rue['phone'];
$tg_ru_id=$tg_rue['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
📞 Nomer olindi
📱Tarmoq: instagram
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=15"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=15"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=20;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 20-₽",
"show_alert"=>true,
]);
}
}

if($callbackdata=="vit"){
if((joinchat($from_id)=="true") and (phonenumber($from_id)=="true") and ($banid==false)){
$j=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=qiwiwallet"),1);
$j2=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=imo"),1);
$j4=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=google"),1);
$j5=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=instagram"),1);
$j6=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=tiktok"),1);
$j7=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=facebook"),1);
$j8=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=prices&product=telegram"),1);
$qi_c=$j['qiwiwallet']['vietnam']['virtual25']['count'];
$fc_c=$j7['facebook']['vietnam']['virtual16']['count'];
$im_c=$j2['imo']['vietnam']['virtual16']['count'];
$go_c=$j4['google']['vietnam']['virtual18']['count'];
$in_c=$j5['instagram']['vietnam']['virtual16']['count'];
$tt_c=$j6['tiktok']['vietnam']['virtual16']['count'];
$tg_c=$j8['telegram']['vietnam']['virtual17']['count'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
Tarmoqlarni tanlang:
🛎Telegram- $tg_c -ta
🛎Imo- $im_c -ta
🛎Instagram - $in_c -ta
🛎QIWl - $qi_c -ta
🛎Google -$go_c -ta
🛎Facebook - $fc_c-ta
🛎TikTok - $tt_c-ta
",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"📲 Telegram 20-₽",'callback_data'=>"vit_tg"]],
[['text'=>" 📲 Imo 15-₽",'callback_data'=>"vit_imo"],['text'=>"🥝 Qiwi 17-₽",'callback_data'=>"vit_qiwi"]],
[['text'=>" 📭 Google 25-₽",'callback_data'=>"vit_gogle"],['text'=>"❤️ Instagram 20-₽",'callback_data'=>"vit_insta"]],
[['text'=>"💙 Facebook 15-₽",'callback_data'=>"vit_face"],['text'=>"🧡 TikTok 16-₽",'callback_data'=>"vit_tiktok"]],
]
]),
]);
}
}

if($callbackdata=="chin_tg" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=24){
$tg_rue=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=china&product=telegram"),1);
$tg_ru_phone=$tg_rue['phone'];
$tg_ru_id=$tg_rue['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
📞 Nomer olindi
📱Tarmoq: Telegram
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=19"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=19"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=24;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 24-₽",
"show_alert"=>true,
]);
}
}

if($callbackdata=="vit_insta" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=20){
$tg_rue=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=vietnam&product=instagram"),1);
$tg_ru_phone=$tg_rue['phone'];
$tg_ru_id=$tg_rue['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
📞 Nomer olindi
📱Tarmoq: Instagram
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=15"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=15"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=20;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 20-₽",
"show_alert"=>true,
]);
}
}

if($callbackdata=="vit_face" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=15){
$tg_rue=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=vietnam&product=facebook"),1);
$tg_ru_phone=$tg_rue['phone'];
$tg_ru_id=$tg_rue['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
📞 Nomer olindi
📱Tarmoq: Facebook
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=10"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=10"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=15;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 15-₽",
"show_alert"=>true,
]);
}
}

if($callbackdata=="vit_gogle" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=25){
$tg_rue=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=vietnam&product=google"),1);
$tg_ru_phone=$tg_rue['phone'];
$tg_ru_id=$tg_rue['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
📞 Nomer olindi
📱Tarmoq: Google
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=20"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=20"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=25;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 25-₽",
"show_alert"=>true,
]);
}
}

if($callbackdata=="vit_qiwi" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=17){
$tg_rue=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=vietnam&product=qiwiwallet"),1);
$tg_ru_phone=$tg_rue['phone'];
$tg_ru_id=$tg_rue['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
📞 Nomer olindi
📱Tarmoq: Qiwi
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=13"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=13"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=17;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 17-₽",
"show_alert"=>true,
]);
}
}

if($callbackdata=="vit_tg" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=20){
$tg_rue=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=vietnam&product=telegram"),1);
$tg_ru_phone=$tg_rue['phone'];
$tg_ru_id=$tg_rue['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
📞 Nomer olindi
📱Tarmoq: Telegram
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=15"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=15"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=20;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 20-₽",
"show_alert"=>true,
]);
}
}

if($callbackdata=="vit_imo" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=15){
$tg_rue=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=vietnam&product=imo"),1);
$tg_ru_phone=$tg_rue['phone'];
$tg_ru_id=$tg_rue['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
📞 Nomer olindi
📱Tarmoq: Imo
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=10"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=10"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=15;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 15-₽",
"show_alert"=>true,
]);
}
}


if($callbackdata=="uz_tiktok" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=20){
$tg_ruq=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=uzbekistan&product=tiktok"),1);
$tg_ru_phone=$tg_ruq['phone'];
$tg_ru_id=$tg_ruq['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
📞 Nomer olindi
📱Tarmoq: tikTok
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=15"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=15"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=20;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 20-₽",
"show_alert"=>true,
]);
}
}

if($callbackdata=="uz_face" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=53){
$tg_ruq=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=uzbekistan&product=facebook"),1);
$tg_ru_phone=$tg_ruq['phone'];
$tg_ru_id=$tg_ruq['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
📞 Nomer olindi
📱Tarmoq: Facebook
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=46"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=46"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=53;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 53-₽",
"show_alert"=>true,
]);
}
}

if($callbackdata=="uz_insta" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=34){
$tg_ruq=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=uzbekistan&product=instagram"),1);
$tg_ru_phone=$tg_ruq['phone'];
$tg_ru_id=$tg_ruq['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
📞 Nomer olindi
📱Tarmoq: Instagram
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=29"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=29"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=34;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 34-₽",
"show_alert"=>true,
]);
}
}

if($callbackdata=="uz_gogle" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=45){
$tg_ruq=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=uzbekistan&product=google"),1);
$tg_ru_phone=$tg_ruq['phone'];
$tg_ru_id=$tg_ruq['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
📞 Nomer olindi
📱Tarmoq: Google
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=39"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=39"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=45;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 45-₽",
"show_alert"=>true,
]);
}
}

if($callbackdata=="uz_imo" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=23){
$tg_ruq=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=uzbekistan&product=imo"),1);
$tg_ru_phone=$tg_ruq['phone'];
$tg_ru_id=$tg_ruq['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"📞 Nomer olindi
📱Tarmoq: Imo
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=18"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=18"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=23;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 23-₽",
"show_alert"=>true,
]);
}
}

if($callbackdata=="uz_qiwi" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=29){
$tg_ruq=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=uzbekistan&product=qiwiwallet"),1);
$tg_ru_phone=$tg_ruq['phone'];
$tg_ru_id=$tg_ruq['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"📞 Nomer olindi
📱Tarmoq: Qiwi
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=23"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=23"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=29;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 29-₽",
"show_alert"=>true,
]);
}
}






if($callbackdata=="ru_tg" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=21){
$tg_rue=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=russia&product=telegram"),1);
$tg_ru_phone=$tg_rue['phone'];
$tg_ru_id=$tg_rue['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"📞 Nomer olindi
📱Tarmoq: Telegram
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=17"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=17"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=21;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 21-₽",
"show_alert"=>true,
]);
}
}

if($callbackdata=="ru_qiwi" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=14){
$tg_rur=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=russia&product=qiwiwallet"),1);
$tg_ru_phone=$tg_rur['phone'];
$tg_ru_id=$tg_rur['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"📞 Nomer olindi
📱Tarmoq: Qiwi
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=11"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=11"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=14;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 14₽",
"show_alert"=>true,
]);
}
}

if($callbackdata=="ru_gogle" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=9){
$tg_rut=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=russia&product=google"),1);
$tg_ru_phone=$tg_rut['phone'];
$tg_ru_id=$tg_rut['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"📞 Nomer olindi
📱Tarmoq: Google
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=7"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=7"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=9;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 9-₽",
"show_alert"=>true,
]);
}
}

if($callbackdata=="ru_insta" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=9){
$tg_ruy=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=russia&product=instagram"),1);
$tg_ru_phone=$tg_ruy['phone'];
$tg_ru_id=$tg_ruy['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"📞 Nomer olindi
📱Tarmoq: Instagram
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=7"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=7"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=9;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 9-₽",
"show_alert"=>true,
]);
}
}

if($callbackdata=="ru_pubg" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=5){
$tg_ruu=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=russia&product=pubg"),1);
$tg_ru_phone=$tg_ruu['phone'];
$tg_ru_id=$tg_ruu['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"📞 Nomer olindi
📱Tarmoq: Pubg
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=3"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=3"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=5;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 5-₽",
"show_alert"=>true,
]);
}
}

if($callbackdata=="ru_tiktok" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=6){
$tg_rui=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=russia&product=tiktok"),1);
$tg_ru_phone=$tg_rui['phone'];
$tg_ru_id=$tg_rui['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"📞 Nomer olindi
📱Tarmoq: TikTok
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=4"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=4"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=6;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 6-₽",
"show_alert"=>true,
]);
}
}

if($callbackdata=="ru_face" and $status=="on" and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false)){
if($sumid>=15){
$tg_ruq=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=number&country=russia&product=facebook"),1);
$tg_ru_phone=$tg_ruq['phone'];
$tg_ru_id=$tg_ruq['id'];
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
📞 Nomer olindi
📱Tarmoq: Facebook
🔢 Nomeringiz: `$tg_ru_phone`
🆔 Buyurtma id `$tg_ru_id`

⚠️ Diqqat 10-daqiqa ichida kodni olmasangiz raqamni bekor qiling 
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni olish",'callback_data'=>"on=code=$tg_ru_id"]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"off=cancel=$tg_ru_id=10"]],
[['text'=>"📛 Ban",'callback_data'=>"ban=ban=$tg_ru_id=10"]],
]
]),
]);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid-=15;
file_put_contents("getsim/$chat_id.pul",$sumid);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Hisobingizda pul yo‘q 15-₽",
"show_alert"=>true,
]);
}
}























//Bu Bot Kodini @UzPhpKod Kanali Orqali Taratim
//GetSim_Bot ni Asl Kodi Faqat Qiwi Avto Tulov olib tashlangan
//Dasturchi @Xasanov_Otabek
//Manbaga Tegma Ereke Bulsang Am Bulsang Tegaver Ruxsat




if((stripos($callbackdata,"ban=")!==false)){
if((joinchat($from_id)=="true") and (phonenumber($from_id)=="true") and ($banid==false)){
$act=explode("=",$callbackdata)[3];
$c=explode("=",$callbackdata)[2];
$can=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=ban&id=$c"),1);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid+=$act;
file_put_contents("getsim/$chat_id.pul",$sumid);
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
🖥 Holat: ".$can['status']."
📛 Ban qilindi tanlang
💳 Hisobingizga qaytarildi: $act  ₽",
'reply_markup'=>$servis,
]);
}
}

if((stripos($callbackdata,"off=")!==false)){
if((joinchat($from_id)=="true") and (phonenumber($from_id)=="true") and ($banid==false)){
$act=explode("=",$callbackdata)[3];
$c=explode("=",$callbackdata)[2];
$can=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=cancel&id=$c"),1);
$sumid = file_get_contents("getsim/$chat_id.pul");
$sumid+=$act;
file_put_contents("getsim/$chat_id.pul",$sumid);
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
🖥 Holat: ".$can['status']."
🚫 Bekor qilindi tanlang
💳 Hisobingizga qaytarildi: $act  ₽",
'reply_markup'=>$servis,
]);
}
}

if((stripos($callbackdata,"on=")!==false and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false))){
$c=explode("=",$callbackdata)[2];
$can=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=code&id=$c"),1);
$cod=$can['sms'][0]['text'];
if($cod!=null){
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
🖥 Kod: ".$cod."",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Kodni qayta olish",'callback_data'=>"on2=code=$c"]],
]
]),
]);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Kod kelmadi kuting $c ".$cod."",
"show_alert"=>true,
]);
}
}

if((stripos($callbackdata,"on2=")!==false and (phonenumber($from_id)!=="true") and (joinchat($from_id)!=="true") and ($banid==false))){
$c=explode("=",$callbackdata)[2];
$can=json_decode(file_get_contents("https://uzbeksila6.clouduz.ru/api/sms.php?act=code&id=$c"),1);
$cod=$can['sms'][1]['text'];
if($cod!=null){
getsim('editMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
🖥 Kod: ".$cod."",
]);
}else{
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>"Kod kelmadi kuting $c ".$cod."",
"show_alert"=>true,
]);
}
}

if($ban==true){
getsim("deleteMessage",[
"chat_id"=>$chatid,
"message_id"=>$messageid,
]);
getsim("sendMessage",[
"chat_id"=>$chatid,
"text"=>"<b>Hurmatli foydalanuvchi!</b>\n<b>Sizga Bot admini tomonidan taqiq qoʻyilgan. Shuning uchun botni ishlata olmaysiz!</b>",
"parse_mode"=>"html",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"📃 Batafsil maʼlumot","callback_data"=>"sabab"],],
]
]),
]);
}

if($banid==true){
getsim("deleteMessage",[
"chat_id"=>$chat_id,
"message_id"=>$message_id,
]);
getsim("sendMessage",[
"chat_id"=>$chat_id,
"text"=>"<b>Hurmatli foydalanuvchi!</b>\n<b>Sizga Bot admini tomonidan taqiq qoʻyilgan. Shuning uchun botni ishlata olmaysiz!</b>",
"parse_mode"=>"html",
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"📃 Batafsil maʼlumot","callback_data"=>"sabab"],],
]
]),
]);
}

if($callbackdata=="sabab"){
getsim("answerCallbackQuery",[
"callback_query_id"=>$id,
"text"=>$sabab,
"show_alert"=>true,
]);
}